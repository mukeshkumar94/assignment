import axios from 'axios';
const API_URL = 'http://localhost:1340';

class ApiService {

    LoginHandler(userDetails) {
        return axios.post(API_URL+'/login', {email:userDetails.email,password:userDetails.password });
    }

    SignupHandler(userDetails) {
        return axios.post(API_URL+'/register', {name:userDetails.name, email:userDetails.email,password:userDetails.password });
    }
}

export default new ApiService();
