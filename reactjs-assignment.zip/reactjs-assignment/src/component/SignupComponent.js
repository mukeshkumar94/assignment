import React from 'react';
import ApiService from "../services/ApiService";

class SignupComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            name:'',
            email: '',
            password: '',
            errorMessage: false,
            token: ''
        }
    }

    componentDidMount() {
    }

    SignupHandler = () => {
        ApiService.SignupHandler(this.state)
          .then((res) => {
              this.setState({
                userDetails: res.data,
                token: res.data.token
              });
        }).catch( error => {
            console.log(error);
        });
    }

    formSubmitHandler = (event) => {
        event.preventDefault();
        if (this.state.name && this.state.email && this.state.password) {
            this.setState({
                errorMessage: false
            });
            this.SignupHandler();
        } else {
            this.setState({
                errorMessage: true,
                token: ''
            });
        }
        
    }

    formChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    render() {
        return (
            <div>
                <form onSubmit={this.formSubmitHandler}>
                    <span>
                        <ul>
                            <li><p>Enter your name:</p></li>
                            <li><input type='text' name='name' value = {this.state.name} onChange={this.formChangeHandler} /></li>
                        </ul>
                    </span>
                    <span>
                        <ul>
                            <li><p>Enter your email:</p></li>
                            <li><input type='text' name='email' value = {this.state.email} onChange={this.formChangeHandler} /></li>
                        </ul>
                    </span>
                    <span>
                        <ul>
                            <li><p>Enter your password:</p></li>
                            <li><input type='password' name='password' value = {this.state.password} onChange={this.formChangeHandler} /></li>
                        </ul>
                    </span>
                    {this.state.errorMessage ? <span className="error_msg">Please provide details.</span> : ''}
                    <span className="btn_submit">
                        <input type='submit' />
                    </span>
                    {this.state.token ? <span className="Token_msg"><b>Your token is :</b> {this.state.token}</span> : ''}
                </form>
            </div>
        );
    }
}

export default SignupComponent;
