import React from 'react';
import {Link} from 'react-router-dom';

class DashboardComponent extends React.Component {
    constructor(props) {
        super(props);
    }
    
    logout = () => {
        localStorage.clear();
        this.props.history.push("/");
    }

    render() {
        this.userDetails = localStorage.getItem('userDetails') || '';
        this.userDetailsObj = this.userDetails ? JSON.parse(JSON.stringify(this.userDetails)) : '';
        var userDetails = this.userDetails ? JSON.parse(this.userDetailsObj) : '';
        var userName = '';
        var email = '';
        var role = '';
        if (userDetails.userObj) {
            userName = userDetails.userObj.name;
            email = userDetails.userObj.email;
            role = userDetails.userObj.role;
        }

        if (this.userDetailsObj) {
            return (
                <div>
                    <b>Dashboard</b> <br/>
                    
                    <span>User Name: {userName}</span><br/>
                    <span>User Eamil: {email}</span><br/>
                    {role === 'admin' ? <span>User Role: {role}</span> : ''}<br/>
        
                    <div className="topbar-right">
                        <ul className="topbar-nav nav">
                          <li className="nav-item">
                            <Link className="nav-link" to="/">Login</Link>
                          </li>
                          <li className="nav-item">
                            <Link className="nav-link" to="/signup">Signup</Link>
                          </li>
                        </ul>

                        <button onClick={this.logout} className="btn_logout">Logout </button>
                    </div>
                </div>
                );
        } else {
            return (
                <div>
                    You are not authorized.
                </div>
            );
        }
     
    }
}

export default DashboardComponent;
