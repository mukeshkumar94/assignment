import React from 'react';
import ApiService from "../services/ApiService";
import {Link} from 'react-router-dom';

class HomeComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            email: '',
            password: '',
            errorMessage: false,
            errorMessageUser: ''
        }
    }

    componentDidMount() {
    }

    LoginHandler = () => {
        ApiService.LoginHandler(this.state)
          .then((res) => {
              if (res.data && res.data.auth) {
                localStorage.setItem('userDetails',JSON.stringify(res.data));
                this.setState({
                  userDetails: res.data
                });
                this.props.history.push("/dashboard");
              } else {
                this.setState({
                    errorMessageUser: 'Invalid user.'
                });
              }
            
        }).catch( error => {
            console.log(error);
        });
    }

    formSubmitHandler = (event) => {
        event.preventDefault();
        if (this.state.email && this.state.password) {
            this.setState({
                errorMessage: false,
                errorMessageUser: ''
            });
            this.LoginHandler();
        } else {
            this.setState({
                errorMessage: true,
                errorMessageUser: ''
            });
        }
        
    }

    formChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    render() {
        return (
            <div>
                <form onSubmit={this.formSubmitHandler}>
                    <span>
                        <ul>
                            <li><p>Enter your email:</p></li>
                            <li><input type='text' name='email' value = {this.state.email} onChange={this.formChangeHandler} /></li>
                        </ul>
                    </span>
                    <span>
                        <ul>
                            <li><p>Enter your password:</p></li>
                            <li><input type='password' name='password' value = {this.state.password} onChange={this.formChangeHandler} /></li>
                        </ul>
                    </span>
                    {this.state.errorMessage ? <span className="error_msg">Please provide details.</span> : ''}
                    {this.state.errorMessageUser ? <span className="error_msg">{this.state.errorMessageUser}</span> : ''}
                    <span className="btn_submit">
                        <input type='submit' />
                    </span>
                    <Link className="nav-link" to="/signup">Sign Up</Link>
                    
                </form>
            </div>
        );
    }
}

export default HomeComponent;
