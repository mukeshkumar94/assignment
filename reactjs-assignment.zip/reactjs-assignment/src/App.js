import React, {Suspense, lazy}  from 'react';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import './App.css';
import './assets/login.css';

const LoginComponent = lazy(() => import('./component/LoginComponent'));
const SignupComponent = lazy(() => import('./component/SignupComponent'));
const DashboardComponent = lazy(() => import('./component/DashboardComponent'));

function App() {
  return (
    <Router>
      <Suspense fallback={<div> Loading ...</div>}>
        <Switch>
          <Route exact path="/" component={LoginComponent} />
          <Route exact path="/signup" component={SignupComponent} />
          <Route exact path="/dashboard" component={DashboardComponent} />
        </Switch>
      </Suspense>
    </Router>
  );
}

export default App;
