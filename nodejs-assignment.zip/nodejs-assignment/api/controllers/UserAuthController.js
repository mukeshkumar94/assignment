var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var config = sails.config.settings;
var userObj = {
    id: 1,
    name: 'admin',
    email: 'admin@gmail.com',
    password: '$2a$08$MlmynkHy55syIl8gB3D87udFmCSJquCvBCWuxOOYH.waewenFApW2',
    role: 'admin'
}

module.exports = (function () {

    function doLogin(req, res) {
        var email = req.body && req.body.email ? req.body.email : '';
        var password = req.body && req.body.password ? req.body.password : '';

        if (email && password) {
            if (userObj.email == email) {
                bcrypt.compare(password, userObj.password, function (err, result) {
                    if (result) {
                        res.json({
                            auth: true,
                            userObj: userObj
                        });
                    } else {
                        res.json({
                            auth: false,
                            message: 'Invalid User'
                        });
                    }
                });
            } else {
                res.json({
                    auth: false,
                    message: 'Invalid User'
                });
            }
        } else {
            res.json({
                auth: false,
                message: 'Please provide email and password.'
            });
        }
    }

    function authAPI(req, res) {
        var token = req.headers['token'];
        if (token) {
            jwt.verify(token, config.secret, function (err, decoded) {
                if (err) {
                    return res.status(500).send({
                        auth: false,
                        message: 'Authenticate token failed.'
                    });
                } else {
                    res.status(200).send(decoded);
                }
            });
        } else {
            return res.status(401).send({
                auth: false,
                message: 'Please provide token.'
            });
        }
    }

    function doSignup(req, res) {
        var name = req.body && req.body.name ? req.body.name : '';
        var email = req.body && req.body.email ? req.body.email : '';
        var password = req.body && req.body.password ? req.body.password : '';

        if (name && email && password) {
            var token = jwt.sign({
                id: Math.floor(Math.random() * 100),
                name: name,
                email: email
            }, config.secret, {
                expiresIn: 86400
            });
            res.json({
                auth: true,
                token: token
            });
        } else {
            res.json({
                auth: false,
                token: ''
            });
        }
    }

    return {
        doLogin: doLogin,
        doSignup: doSignup,
        authAPI: authAPI
    };

})();