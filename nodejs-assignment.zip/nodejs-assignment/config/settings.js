module.exports.settings = {
    secret: '45VDFGFDG46464RTY456'
};